<?php
/* ==========================================================================
   counter.php — visitor counter for the ONOS APC Support Hub

   Self-hosted on the Library's own cPanel space. No third-party service, no
   cookies, no personal data stored: the only thing written to disk is a
   running total and a short-lived hash used to avoid double-counting.

   HOW IT IS USED
   --------------
   The pages fetch this file with JavaScript; it returns JSON:

       { "total": 1234, "today": 17 }

   Call it with ?peek=1 to read the figures without incrementing — handy for
   checking the number yourself without inflating it.

   INSTALLATION
   ------------
   1. Upload counter.php next to index.html.
   2. That is all. The data file is created automatically on first visit.

   If PHP is unavailable, nothing breaks — the counter simply stays hidden.

   WHAT IT COUNTS
   --------------
   A "visit" is one browser in one 12-hour window, not one page load: moving
   between the four pages counts once. De-duplication uses a salted hash of
   the IP and user-agent, which cannot be reversed to identify anyone, and the
   hashes are discarded after 24 hours.

   Obvious bots are ignored. That keeps the figure closer to real people than
   a naive hit counter, though no counter is exact.
   ========================================================================== */

declare(strict_types=1);

// --------------------------------------------------------------------------
// Where the data lives. Keep it out of the web root if you can; if that is
// not possible the .htaccess shipped alongside blocks direct access to .json.
// --------------------------------------------------------------------------
const DATA_FILE = __DIR__ . '/counter-data.json';

// Change this to any random string. It salts the visitor hashes so they
// cannot be matched against another site's.
const SALT = 'iitgn-onos-apc-2026-change-me';

// A repeat visit within this many seconds is not counted again.
const VISIT_WINDOW = 43200;   // 12 hours

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/** Load the store, tolerating a missing or damaged file. */
function load(): array {
    $blank = ['total' => 0, 'days' => [], 'seen' => []];
    if (!is_file(DATA_FILE)) {
        return $blank;
    }
    $raw = @file_get_contents(DATA_FILE);
    if ($raw === false || $raw === '') {
        return $blank;
    }
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['total'])) {
        return $blank;   // corrupted: start again rather than fail
    }
    $data += $blank;
    return $data;
}

/** Rough bot filter. Not exhaustive, but removes the bulk of crawler noise. */
function isBot(string $ua): bool {
    if ($ua === '') {
        return true;
    }
    return (bool) preg_match(
        '/bot|crawl|spider|slurp|bing|yandex|baidu|duckduck|facebookexternalhit|'
        . 'preview|monitor|curl|wget|python-requests|headless|lighthouse|pingdom|uptime/i',
        $ua
    );
}

$peek = isset($_GET['peek']);
$today = gmdate('Y-m-d');

// --------------------------------------------------------------------------
// Read-modify-write under an exclusive lock, so simultaneous visitors cannot
// overwrite each other's increment.
// --------------------------------------------------------------------------
$fh = @fopen(DATA_FILE, 'c+');
if ($fh === false) {
    // Cannot write (permissions, read-only disk). Report rather than crash;
    // the page hides the counter when it sees an error.
    http_response_code(200);
    echo json_encode(['error' => 'counter file not writable']);
    exit;
}

flock($fh, LOCK_EX);

$raw = stream_get_contents($fh);
$data = ['total' => 0, 'days' => [], 'seen' => []];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded) && isset($decoded['total'])) {
        $data = $decoded + $data;
    }
}

$counted = false;

if (!$peek) {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
    $ip = trim(explode(',', $ip)[0]);

    if (!isBot($ua)) {
        $key = substr(hash('sha256', SALT . '|' . $ip . '|' . $ua), 0, 16);
        $now = time();

        // Drop expired hashes so the file cannot grow without bound.
        foreach ($data['seen'] as $k => $t) {
            if ($t < $now - VISIT_WINDOW) {
                unset($data['seen'][$k]);
            }
        }

        if (!isset($data['seen'][$key])) {
            $data['total'] = (int) $data['total'] + 1;
            $data['days'][$today] = (int) ($data['days'][$today] ?? 0) + 1;
            $data['seen'][$key] = $now;
            $counted = true;
        }
    }

    // Keep only the last 400 days of daily figures.
    if (count($data['days']) > 400) {
        ksort($data['days']);
        $data['days'] = array_slice($data['days'], -400, null, true);
    }

    if ($counted) {
        ftruncate($fh, 0);
        rewind($fh);
        fwrite($fh, json_encode($data));
        fflush($fh);
    }
}

flock($fh, LOCK_UN);
fclose($fh);

echo json_encode([
    'total' => (int) $data['total'],
    'today' => (int) ($data['days'][$today] ?? 0),
]);
