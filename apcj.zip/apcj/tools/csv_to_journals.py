#!/usr/bin/env python3
"""
csv_to_journals.py — turn the official ONOS APC title list into journals-data.js

USAGE
    python tools/csv_to_journals.py APC_Journal_Titles.csv -o assets/journals-data.js

Download the source file from https://www.onos.gov.in/apc-support (the
"Download" button on the eligible-titles table). Re-run this whenever
INFLIBNET revises the list — nothing else on the site needs touching, because
every journal count reads JOURNALS.length.

WHAT IT HANDLES
  * Preamble rows. The official export puts three note lines and a blank line
    above the real header; the script scans the first 25 rows for the header
    instead of assuming row 1.
  * Column-name variants (see ALIASES) — case- and punctuation-insensitive.
  * Delimiter sniffing (comma / semicolon / tab / pipe).
  * Multi-valued Subjects cells, split into a list.
  * Duplicate titles and blank rows, which are dropped.

OUTPUT RECORD
    title    (string)  Journal title
    issn     (string)  Print ISSN, "" if none
    eissn    (string)  Online ISSN, "" if none
    subjects (array)   Subject tags, [] if none
"""

import argparse
import csv
import json
import os
import re
import sys
from datetime import date

ALIASES = {
    "title": ["title", "journaltitle", "journalname", "publicationname",
              "sourcetitle", "nameofjournal", "journal"],
    "issn": ["issn", "printissn", "pissn", "issnprint"],
    "eissn": ["eissn", "onlineissn", "electronicissn", "issnonline", "eissnonline"],
    "subjects": ["subjects", "subject", "subjectarea", "subjectareas",
                 "subjectcategory", "discipline", "asjc", "category", "categories"],
    # Not present in the official ONOS export, but supported if your file has them:
    "publisher": ["publisher", "publishername"],
    "url": ["url", "link", "journalurl", "homepage", "website"],
}

# Order of keys in the emitted objects. publisher/url are only emitted if the
# source actually had them, so the common case stays compact.
CORE = ["title", "issn", "eissn", "subjects"]
OPTIONAL = ["publisher", "url"]

HEADER_SCAN_ROWS = 25

# --------------------------------------------------------------------------
# The ONOS export separates subject tags with commas — but a number of Scopus
# ASJC category names contain commas of their own, so a naive split shreds
# them ("Ecology, Evolution, Behavior and Systematics" becomes three bogus
# tags). These names are protected before splitting and restored afterwards.
#
# Add to this list if a future revision of the list introduces another
# comma-bearing category. Run with --audit to see tags that look like
# fragments of a split name.
# --------------------------------------------------------------------------
COMMA_CATEGORIES = [
    "Ecology, Evolution, Behavior and Systematics",
    "Atomic and Molecular Physics, and Optics",
    "Public Health, Environmental and Occupational Health",
    "Physical Therapy, Sports Therapy and Rehabilitation",
    "Renewable Energy, Sustainability and the Environment",
    "Pharmacology, Toxicology and Pharmaceutics",
    "Biochemistry, Genetics and Molecular Biology",
    "Management, Monitoring, Policy and Law",
    "Pediatrics, Perinatology and Child Health",
    "Radiology, Nuclear Medicine and Imaging",
    "Tourism, Leisure and Hospitality Management",
    "Economics, Econometrics and Finance",
    "Electronic, Optical and Magnetic Materials",
    "Business, Management and Accounting",
    "Statistics, Probability and Uncertainty",
    "Safety, Risk, Reliability and Quality",
    "Geography, Planning and Development",
    "Health, Toxicology and Mutagenesis",
    "Issues, Ethics and Legal Aspects",
    "Surfaces, Coatings and Films",
]

# The export also uses "General <category>" forms of the same names.
PROTECTED = sorted(
    {c for c in COMMA_CATEGORIES} | {"General " + c for c in COMMA_CATEGORIES},
    key=len, reverse=True,          # longest first, so prefixes don't win
)

SENTINEL = "\x00%d\x00"


def slug(s):
    return re.sub(r"[^a-z0-9]", "", str(s or "").lower())


def map_row(cells):
    """Return {field: column_index} for a candidate header row."""
    lookup = {}
    for field, names in ALIASES.items():
        for n in names:
            lookup[slug(n)] = field
    mapping = {}
    for i, c in enumerate(cells):
        f = lookup.get(slug(c))
        if f and f not in mapping:
            mapping[f] = i
    return mapping


def clean(v):
    return re.sub(r"\s+", " ", str(v or "")).strip()


def split_subjects(v):
    """Split a Subjects cell into tags, keeping comma-bearing ASJC names whole."""
    s = clean(v)
    if not s:
        return []

    # 1. Hide protected names behind sentinels so their commas survive.
    for i, name in enumerate(PROTECTED):
        s = re.sub(re.escape(name), SENTINEL % i, s, flags=re.IGNORECASE)

    # 2. Now it is safe to split on the real separators.
    out = []
    for part in re.split(r"[;,|]", s):
        part = clean(part)
        if not part:
            continue
        # 3. Restore.
        m = re.fullmatch(r"\x00(\d+)\x00", part)
        if m:
            part = PROTECTED[int(m.group(1))]
        if part not in out:
            out.append(part)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csvfile")
    ap.add_argument("-o", "--out", help="write here instead of stdout")
    args = ap.parse_args()

    if not os.path.exists(args.csvfile):
        sys.exit("error: file not found: %s" % args.csvfile)

    with open(args.csvfile, "r", encoding="utf-8-sig", newline="") as fh:
        sample = fh.read(8192)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.reader(fh, dialect))

    # ---- locate the header row, skipping any preamble notes ----------------
    header_idx, colmap = None, None
    for i, r in enumerate(rows[:HEADER_SCAN_ROWS]):
        m = map_row(r)
        if "title" in m:
            header_idx, colmap = i, m
            break

    if header_idx is None:
        sys.exit(
            "error: no header row with a recognisable journal-title column was\n"
            "       found in the first %d rows. Rename the column to\n"
            "       'Journal Title', or add an alias to ALIASES['title']."
            % HEADER_SCAN_ROWS
        )

    if header_idx:
        sys.stderr.write("note: skipped %d preamble row(s); header found on line %d\n"
                         % (header_idx, header_idx + 1))

    fields = CORE + [f for f in OPTIONAL if f in colmap]

    records, seen, skipped = [], set(), 0
    for raw in rows[header_idx + 1:]:
        if not raw or not any(clean(c) for c in raw):
            continue
        title = clean(raw[colmap["title"]]) if colmap["title"] < len(raw) else ""
        if not title:
            skipped += 1
            continue
        key = title.lower()
        if key in seen:
            skipped += 1
            continue
        seen.add(key)

        rec = {"title": title}
        for f in fields[1:]:
            idx = colmap.get(f)
            val = clean(raw[idx]) if idx is not None and idx < len(raw) else ""
            rec[f] = split_subjects(val) if f == "subjects" else val
        records.append(rec)

    records.sort(key=lambda r: r["title"].lower())

    n_sub = len({s for r in records for s in r.get("subjects", [])})

    out = []
    out.append("/* ==========================================================================")
    out.append("   journals-data.js — ONOS APC eligible journal list")
    out.append("   AUTO-GENERATED by tools/csv_to_journals.py — do not hand-edit.")
    out.append("   Source      : %s" % os.path.basename(args.csvfile))
    out.append("   Generated   : %s" % date.today().isoformat())
    out.append("   Journals    : %d" % len(records))
    out.append("   Subject tags: %d distinct" % n_sub)
    out.append("")
    out.append("   Authoritative source: https://www.onos.gov.in/apc-support")
    out.append("   ========================================================================== */")
    out.append("")
    out.append("const JOURNALS_IS_SAMPLE = false;")
    out.append("")
    out.append("const JOURNALS = [")
    for i, r in enumerate(records):
        parts = ", ".join("%s: %s" % (f, json.dumps(r[f], ensure_ascii=False)) for f in fields)
        out.append("  { %s }%s" % (parts, "," if i < len(records) - 1 else ""))
    out.append("];")
    out.append("")
    text = "\n".join(out)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        target = args.out
    else:
        sys.stdout.write(text)
        target = "stdout"

    sys.stderr.write("wrote %d journals (%d subject tags) to %s%s\n"
                     % (len(records), n_sub, target,
                        "; skipped %d row(s)" % skipped if skipped else ""))


if __name__ == "__main__":
    main()
