#!/usr/bin/env python3
"""
build.py — inline the stylesheet into every page.

    python tools/build.py

Why this exists
---------------
The site must not depend on anything external, so the CSS is embedded in each
HTML file rather than linked. Keeping four hand-maintained copies of a 900-line
stylesheet would be unworkable, so assets/style.css stays the single source of
truth and this script copies it into each page's <style> block.

Each page carries a marker:

    <style data-inline="assets/style.css">…</style>

Everything between those tags is replaced with the current file contents. The
script is idempotent — run it as often as you like. Run it after every edit to
assets/style.css, otherwise the pages keep serving the previous version.

Options
-------
    --check     report whether any page is stale, change nothing, exit 1 if so.
                Useful in a pre-commit hook or CI step.
"""

import argparse
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAGES = ["index.html", "guidelines.html", "faq.html", "onoslist.html"]

# Captures: 1 = opening tag, 2 = current contents, 3 = closing tag
BLOCK = re.compile(
    r'(<style\s+data-inline="([^"]+)"\s*>)(.*?)(</style>)',
    re.S | re.I,
)


def banner(src_name):
    return (
        "\n/* ============================================================\n"
        "   Inlined from %s by tools/build.py.\n"
        "   Do not edit here — edit that file and re-run the script.\n"
        "   ============================================================ */\n"
    ) % src_name


def process(path, check_only):
    with open(path, "r", encoding="utf-8") as f:
        html = f.read()

    found = [0]
    stale = [False]

    def repl(m):
        found[0] += 1
        open_tag, src_rel, current, close_tag = m.group(1), m.group(2), m.group(3), m.group(4)
        src_path = os.path.join(ROOT, src_rel)
        if not os.path.exists(src_path):
            sys.exit("error: %s references %s, which does not exist" % (path, src_rel))
        with open(src_path, "r", encoding="utf-8") as f:
            css = f.read().rstrip()
        # A stray </style> inside the CSS would close the block early.
        if "</style" in css.lower():
            sys.exit("error: %s contains a literal '</style' and cannot be inlined" % src_rel)
        new = banner(src_rel) + css + "\n"
        if new != current:
            stale[0] = True
        return open_tag + new + close_tag

    out = BLOCK.sub(repl, html)

    if found[0] == 0:
        print("  %-16s no <style data-inline=…> marker — skipped" % os.path.basename(path))
        return False

    if check_only:
        print("  %-16s %s" % (os.path.basename(path), "STALE" if stale[0] else "up to date"))
        return stale[0]

    if stale[0]:
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print("  %-16s updated (%d block(s), %d KB inlined)"
              % (os.path.basename(path), found[0], len(out.encode()) // 1024))
    else:
        print("  %-16s already current" % os.path.basename(path))
    return stale[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--check", action="store_true",
                    help="report staleness without writing; exit 1 if any page is stale")
    args = ap.parse_args()

    print("inlining CSS %s" % ("(check only)" if args.check else ""))
    any_stale = False
    for name in PAGES:
        p = os.path.join(ROOT, name)
        if not os.path.exists(p):
            print("  %-16s missing — skipped" % name)
            continue
        any_stale |= process(p, args.check)

    if args.check and any_stale:
        print("\nSome pages are stale. Run: python tools/build.py")
        sys.exit(1)
    print("done")


if __name__ == "__main__":
    main()
