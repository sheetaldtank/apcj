# ONOS APC Support Hub — IIT Gandhinagar Library

A four-page static site for the ONOS Article Processing Charge scheme. No framework, no server-side
code, and **no external requests of any kind** — copy the folder to any web server and it runs.

```
apcj/
├── index.html          Overview, resource cards, five-step process, contacts
├── guidelines.html     Full guidelines, sticky contents sidebar with scroll-spy, print stylesheet
├── faq.html            31 questions, live search + topic filters, deep-linkable (#q19)
├── onoslist.html       Journal browser: search, A–Z, subject facet, sort, paging, CSV export
├── assets/
│   ├── style.css       Single source of truth for styling (inlined into the pages)
│   ├── site.js         SITE config, config interpolation, nav, scroll-spy, shared helpers
│   ├── journals-data.js  426 eligible journals — regenerate, don't hand-edit
│   ├── onoslist.js     Journal browser logic
│   ├── faq.js          FAQ search/filter logic
│   └── library-logo.png  IITGN Library wordmark
├── tools/
│   ├── build.py        Inlines style.css into all four pages
│   └── csv_to_journals.py  Converts the official ONOS CSV into journals-data.js
└── APC_Journal_Titles.csv  Source list, downloaded 14 Aug 2026
```

---

## The one thing still to confirm

`SITE.signingAuth` in `assets/site.js` is set to **"Dean, Academic Affairs"** as a placeholder. The
ONOS admin panel doesn't record who signs the Head-of-Institution endorsement, and I couldn't verify
it from any public source. It appears in about eight places across the site.

Confirm it with the Dean's office, then:

1. change the one value in `SITE`;
2. delete the three `<span class="tag amber">Confirm locally</span>` markers (index.html, guidelines.html §5, faq.html Q19).

Everything else is taken from your ONOS institute administration panel and is live:
institute code **U-0139**, Nodal Officer **Dr. Kannan Palavesam**, **librarian@iitgn.ac.in**,
**079 3245 1126**, Main Library Block 13.

---

## Editing the site

### Text that appears in many places

All institution-specific strings live in one `SITE` object at the top of `assets/site.js`. Change a
value there and it updates across all four pages — the HTML carries `data-cfg="key"` attributes that
`site.js` fills in on load. The text sitting inside those elements in the HTML is a fallback for when
JavaScript is off; if you need the site to work fully without JS, find-and-replace that too.

### Styling

`assets/style.css` is the source of truth, but the pages don't link to it — the CSS is **embedded**
in each page's `<style>` block so nothing is fetched at runtime. After any CSS edit run:

```bash
python tools/build.py          # re-inline into all four pages
python tools/build.py --check  # CI/pre-commit: exit 1 if any page is stale
```

Forgetting this is the one easy mistake: the pages keep serving the previous stylesheet. `--check`
exists so a hook can catch it.

### The journal list

```bash
# Download the latest list from https://www.onos.gov.in/apc-support
python tools/csv_to_journals.py APC_Journal_Titles.csv -o assets/journals-data.js
```

The converter handles the quirks of the official export:

- **Preamble rows.** The file has three note lines and a blank line above the real header; the script
  scans for the header rather than assuming row 1.
- **Comma-bearing subject names.** Subjects are comma-separated, but several Scopus ASJC categories
  contain commas themselves — a naive split turns *"Ecology, Evolution, Behavior and Systematics"*
  into three bogus tags. Twenty such names are protected in `COMMA_CATEGORIES`; add to that list if a
  future revision introduces another.
- Delimiter sniffing, duplicate titles, blank rows, and alphabetical sorting.

Current data: **426 journals, 258 distinct subject tags.**

Every journal count on the site reads `JOURNALS.length`, so the hero figure, the guidelines and FAQ
answers 3, 7 and 10 all update themselves. There is no number to maintain by hand.

---

## Design

Colours and UI conventions were sampled from the Library's own e-Journals Discovery page, so the hub
sits alongside `library.iitgn.ac.in` rather than looking like a separate site:

| Role | Value |
|---|---|
| Page ground | slate-100 `#F1F5F9` |
| Cards | white, 12px radius, soft shadow |
| Headings / body | slate-800 `#1E293B` / slate-600 `#475569` |
| Links / buttons | blue-700 `#1D4ED8` / blue-600 `#2563EB` |
| Subject pills | emerald, violet and blue tints |
| Brand | red `#EC1F28`, blue `#1971B8`, sampled from the wordmark |

Type is a system font stack — no webfonts, so nothing is downloaded and text renders instantly.

The journal browser deliberately mirrors the e-Journals page: search pill, A–Z strip in its own card,
a "Refine results" sidebar, a large result count, and result cards with coloured subject pills.

## How the code works

**`site.js`** runs everywhere. On load it interpolates `data-cfg` and `data-jcount` attributes,
marks the current nav item by comparing `location.pathname` to each link's `href`, wires the
back-to-top button, and drives the guidelines scroll-spy. It also exports the shared helpers
(`esc`, `norm`, `highlight`, `debounce`, `downloadBlob`).

**`onoslist.js`** keeps one `state` object — query, letter, subject, sort, page, page size. Every
control mutates state and calls a single `render()`; nothing else touches the DOM. Each record's
search text is normalised **once at load** rather than per keystroke, which matters at 426 records.
Search is AND-across-tokens over title, both ISSNs and subjects, accent-folded so *"Zeitschrift für"*
matches *"zeitschrift fur"*, debounced at 160 ms. Subject pill colours are hashed from the subject
name, so a tag looks the same everywhere. Pressing `/` focuses the search box.

**CSV export writes the currently filtered set**, not the whole list — so "all Oncology journals" is
two clicks. Output is UTF-8 with a BOM so Excel opens it correctly.

**`faq.js`** caches each question's normalised text at load, then filters on `indexOf`. Matches
auto-expand while typing and collapse when cleared; a topic heading hides itself when none of its
questions survive. Questions have stable ids, so `faq.html#q19` opens and scrolls to that answer —
useful when replying to an email.

**`guidelines.html`** has no JS of its own. Its print stylesheet drops the nav, sidebar and buttons,
so *Print → Save as PDF* produces a clean handout, which is what the sidebar button does.

## Verified

43 runtime checks (search, facets, sort, paging, CSV contents and encoding, XSS-safe highlighting,
subject parsing) and ~140 static checks (no external requests, inlined CSS byte-identical to source,
every `data-cfg` key defined, every element id present, anchors and links resolve, no duplicate ids,
balanced markup, every CSS class defined).

## Content accuracy

The process content — eligibility, the eight portal steps, INFLIBNET's invoice address and
GSTIN/PAN, the liability clauses, the 15–20 working day payment window — should be cross-checked
against the official documents before publishing:

- <https://www.onos.gov.in/public/docs/APC-Guidelines-V1.pdf>
- <https://www.onos.gov.in/public/docs/APC_Manual_v3.pdf>

Update `SITE.reviewed` when you do; it renders in every footer.

## Browser support

Current Chrome, Edge, Firefox and Safari. Uses `<dialog>`, `Element.closest`, `String.normalize`,
CSS custom properties and `:has()`. Fully responsive; the facet sidebar stacks below 940px.
