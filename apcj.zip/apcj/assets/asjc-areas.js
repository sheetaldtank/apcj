/* ==========================================================================
   asjc-areas.js — maps fine-grained Scopus subject names to the 27 top-level
   ASJC subject areas, so the journal list can offer a broad-subject filter
   alongside the ~260 detailed tags.

   WHY THIS EXISTS
   ---------------
   The ONOS export gives only the narrow categories ("Agronomy and Crop
   Science", "Cellular and Molecular Neuroscience"). Researchers usually want
   to browse by discipline — "show me the Engineering journals" — which means
   rolling those up to the ASJC top level.

   HOW A NAME IS RESOLVED
   ----------------------
   1. Self-naming tags need no table: "General Engineering" and
      "Engineering (miscellaneous)" both resolve to Engineering.
   2. Everything else is looked up in SUB_TO_AREA below.
   3. Anything unrecognised is skipped, and recorded in ONOS.unmappedSubjects
      so it can be found and added rather than silently disappearing.

   MAINTAINING IT
   --------------
   If a revised ONOS list introduces a subject name that is not here, the
   journal simply won't appear under a broad area — its detailed tags still
   work. Open the browser console on the Journal List page and look at
   ONOS.unmappedSubjects to see what needs adding.

   A few judgement calls worth knowing about, because ASJC is not always
   intuitive:
     · Nutrition and Dietetics, Gerontology and Leadership and Management sit
       under Nursing in ASJC, not Medicine or Business.
     · Theoretical Computer Science and Modelling and Simulation sit under
       Mathematics, not Computer Science.
     · "X (medical)" variants — Microbiology (medical), Pharmacology
       (medical), Physiology (medical) — belong to Medicine, while the plain
       names belong to their own science area.
     · Health Policy, Health Informatics and Epidemiology are Medicine;
       Health (social science) is Social Sciences.
   ========================================================================== */

var ONOS = window.ONOS || (window.ONOS = {});

/** The 27 top-level ASJC subject areas. */
ONOS.AREAS = [
  'Agricultural and Biological Sciences',
  'Arts and Humanities',
  'Biochemistry, Genetics and Molecular Biology',
  'Business, Management and Accounting',
  'Chemical Engineering',
  'Chemistry',
  'Computer Science',
  'Decision Sciences',
  'Dentistry',
  'Earth and Planetary Sciences',
  'Economics, Econometrics and Finance',
  'Energy',
  'Engineering',
  'Environmental Science',
  'Health Professions',
  'Immunology and Microbiology',
  'Materials Science',
  'Mathematics',
  'Medicine',
  'Multidisciplinary',
  'Neuroscience',
  'Nursing',
  'Pharmacology, Toxicology and Pharmaceutics',
  'Physics and Astronomy',
  'Psychology',
  'Social Sciences',
  'Veterinary'
];

/** Narrow subject name (lower-cased) -> top-level area. */
ONOS.SUB_TO_AREA = {
  /* ---- Agricultural and Biological Sciences ---------------------------- */
  'agronomy and crop science': 'Agricultural and Biological Sciences',
  'animal science and zoology': 'Agricultural and Biological Sciences',
  'aquatic science': 'Agricultural and Biological Sciences',
  'ecology': 'Agricultural and Biological Sciences',
  'ecology, evolution, behavior and systematics': 'Agricultural and Biological Sciences',
  'food science': 'Agricultural and Biological Sciences',
  'forestry': 'Agricultural and Biological Sciences',
  'horticulture': 'Agricultural and Biological Sciences',
  'insect science': 'Agricultural and Biological Sciences',
  'plant science': 'Agricultural and Biological Sciences',
  'soil science': 'Agricultural and Biological Sciences',

  /* ---- Arts and Humanities --------------------------------------------- */
  'archaeology': 'Arts and Humanities',
  'classics': 'Arts and Humanities',
  'conservation': 'Arts and Humanities',
  'history': 'Arts and Humanities',
  'history and philosophy of science': 'Arts and Humanities',
  'language and linguistics': 'Arts and Humanities',
  'literature and literary theory': 'Arts and Humanities',
  'museology': 'Arts and Humanities',
  'music': 'Arts and Humanities',
  'philosophy': 'Arts and Humanities',
  'religious studies': 'Arts and Humanities',
  'visual arts and performing arts': 'Arts and Humanities',

  /* ---- Biochemistry, Genetics and Molecular Biology --------------------- */
  'biochemistry': 'Biochemistry, Genetics and Molecular Biology',
  'biophysics': 'Biochemistry, Genetics and Molecular Biology',
  'biotechnology': 'Biochemistry, Genetics and Molecular Biology',
  'cancer research': 'Biochemistry, Genetics and Molecular Biology',
  'cell biology': 'Biochemistry, Genetics and Molecular Biology',
  'clinical biochemistry': 'Biochemistry, Genetics and Molecular Biology',
  'developmental biology': 'Biochemistry, Genetics and Molecular Biology',
  'endocrinology': 'Biochemistry, Genetics and Molecular Biology',
  'genetics': 'Biochemistry, Genetics and Molecular Biology',
  'molecular biology': 'Biochemistry, Genetics and Molecular Biology',
  'molecular medicine': 'Biochemistry, Genetics and Molecular Biology',
  'physiology': 'Biochemistry, Genetics and Molecular Biology',
  'structural biology': 'Biochemistry, Genetics and Molecular Biology',
  'ageing': 'Biochemistry, Genetics and Molecular Biology',
  'aging': 'Biochemistry, Genetics and Molecular Biology',

  /* ---- Business, Management and Accounting ------------------------------ */
  'accounting': 'Business, Management and Accounting',
  'business and international management': 'Business, Management and Accounting',
  'industrial relations': 'Business, Management and Accounting',
  'management information systems': 'Business, Management and Accounting',
  'management of technology and innovation': 'Business, Management and Accounting',
  'marketing': 'Business, Management and Accounting',
  'organizational behavior and human resource management': 'Business, Management and Accounting',
  'strategy and management': 'Business, Management and Accounting',
  'tourism, leisure and hospitality management': 'Business, Management and Accounting',

  /* ---- Chemical Engineering -------------------------------------------- */
  'bioengineering': 'Chemical Engineering',
  'catalysis': 'Chemical Engineering',
  'chemical health and safety': 'Chemical Engineering',
  'colloid and surface chemistry': 'Chemical Engineering',
  'filtration and separation': 'Chemical Engineering',
  'fluid flow and transfer processes': 'Chemical Engineering',
  'process chemistry and technology': 'Chemical Engineering',

  /* ---- Chemistry -------------------------------------------------------- */
  'analytical chemistry': 'Chemistry',
  'electrochemistry': 'Chemistry',
  'inorganic chemistry': 'Chemistry',
  'organic chemistry': 'Chemistry',
  'physical and theoretical chemistry': 'Chemistry',
  'spectroscopy': 'Chemistry',

  /* ---- Computer Science -------------------------------------------------- */
  'artificial intelligence': 'Computer Science',
  'computational theory and mathematics': 'Computer Science',
  'computer graphics and computer-aided design': 'Computer Science',
  'computer networks and communications': 'Computer Science',
  'computer science applications': 'Computer Science',
  'computer vision and pattern recognition': 'Computer Science',
  'hardware and architecture': 'Computer Science',
  'human-computer interaction': 'Computer Science',
  'information systems': 'Computer Science',
  'signal processing': 'Computer Science',
  'software': 'Computer Science',

  /* ---- Decision Sciences ------------------------------------------------- */
  'information systems and management': 'Decision Sciences',
  'management science and operations research': 'Decision Sciences',
  'statistics, probability and uncertainty': 'Decision Sciences',

  /* ---- Dentistry --------------------------------------------------------- */
  'dental assisting': 'Dentistry',
  'dental hygiene': 'Dentistry',
  'oral surgery': 'Dentistry',
  'orthodontics': 'Dentistry',
  'periodontics': 'Dentistry',

  /* ---- Earth and Planetary Sciences -------------------------------------- */
  'atmospheric science': 'Earth and Planetary Sciences',
  'computers in earth sciences': 'Earth and Planetary Sciences',
  'earth-surface processes': 'Earth and Planetary Sciences',
  'economic geology': 'Earth and Planetary Sciences',
  'geochemistry and petrology': 'Earth and Planetary Sciences',
  'geology': 'Earth and Planetary Sciences',
  'geophysics': 'Earth and Planetary Sciences',
  'geotechnical engineering and engineering geology': 'Earth and Planetary Sciences',
  'oceanography': 'Earth and Planetary Sciences',
  'paleontology': 'Earth and Planetary Sciences',
  'space and planetary science': 'Earth and Planetary Sciences',
  'stratigraphy': 'Earth and Planetary Sciences',

  /* ---- Economics, Econometrics and Finance -------------------------------- */
  'economics and econometrics': 'Economics, Econometrics and Finance',
  'finance': 'Economics, Econometrics and Finance',

  /* ---- Energy ------------------------------------------------------------- */
  'energy engineering and power technology': 'Energy',
  'fuel technology': 'Energy',
  'nuclear energy and engineering': 'Energy',
  'renewable energy, sustainability and the environment': 'Energy',

  /* ---- Engineering -------------------------------------------------------- */
  'aerospace engineering': 'Engineering',
  'architecture': 'Engineering',
  'automotive engineering': 'Engineering',
  'biomedical engineering': 'Engineering',
  'building and construction': 'Engineering',
  'civil and structural engineering': 'Engineering',
  'computational mechanics': 'Engineering',
  'control and systems engineering': 'Engineering',
  'electrical and electronic engineering': 'Engineering',
  'industrial and manufacturing engineering': 'Engineering',
  'mechanical engineering': 'Engineering',
  'mechanics of materials': 'Engineering',
  'media technology': 'Engineering',
  'ocean engineering': 'Engineering',
  'safety, risk, reliability and quality': 'Engineering',

  /* ---- Environmental Science ---------------------------------------------- */
  'ecological modelling': 'Environmental Science',
  'environmental chemistry': 'Environmental Science',
  'environmental engineering': 'Environmental Science',
  'global and planetary change': 'Environmental Science',
  'health, toxicology and mutagenesis': 'Environmental Science',
  'management, monitoring, policy and law': 'Environmental Science',
  'nature and landscape conservation': 'Environmental Science',
  'pollution': 'Environmental Science',
  'waste management and disposal': 'Environmental Science',
  'water science and technology': 'Environmental Science',

  /* ---- Health Professions -------------------------------------------------- */
  'chiropractics': 'Health Professions',
  'complementary and manual therapy': 'Health Professions',
  'emergency medical services': 'Health Professions',
  'health information management': 'Health Professions',
  'medical assisting and transcription': 'Health Professions',
  'medical laboratory technology': 'Health Professions',
  'medical terminology': 'Health Professions',
  'occupational therapy': 'Health Professions',
  'optometry': 'Health Professions',
  'pharmacy': 'Health Professions',
  'physical therapy, sports therapy and rehabilitation': 'Health Professions',
  'podiatry': 'Health Professions',
  'radiological and ultrasound technology': 'Health Professions',
  'respiratory care': 'Health Professions',
  'speech and hearing': 'Health Professions',

  /* ---- Immunology and Microbiology ------------------------------------------ */
  'applied microbiology and biotechnology': 'Immunology and Microbiology',
  'immunology': 'Immunology and Microbiology',
  'microbiology': 'Immunology and Microbiology',
  'parasitology': 'Immunology and Microbiology',
  'virology': 'Immunology and Microbiology',

  /* ---- Materials Science ---------------------------------------------------- */
  'biomaterials': 'Materials Science',
  'ceramics and composites': 'Materials Science',
  'electronic, optical and magnetic materials': 'Materials Science',
  'materials chemistry': 'Materials Science',
  'metals and alloys': 'Materials Science',
  'nanoscience and nanotechnology': 'Materials Science',
  'polymers and plastics': 'Materials Science',
  'surfaces, coatings and films': 'Materials Science',

  /* ---- Mathematics ----------------------------------------------------------- */
  'algebra and number theory': 'Mathematics',
  'analysis': 'Mathematics',
  'applied mathematics': 'Mathematics',
  'computational mathematics': 'Mathematics',
  'control and optimization': 'Mathematics',
  'discrete mathematics and combinatorics': 'Mathematics',
  'geometry and topology': 'Mathematics',
  'logic': 'Mathematics',
  'mathematical physics': 'Mathematics',
  'modelling and simulation': 'Mathematics',
  'modeling and simulation': 'Mathematics',
  'numerical analysis': 'Mathematics',
  'statistics and probability': 'Mathematics',
  'theoretical computer science': 'Mathematics',

  /* ---- Medicine --------------------------------------------------------------- */
  'anatomy': 'Medicine',
  'anesthesiology and pain medicine': 'Medicine',
  'biochemistry (medical)': 'Medicine',
  'cardiology and cardiovascular medicine': 'Medicine',
  'clinical neurology': 'Medicine',
  'complementary and alternative medicine': 'Medicine',
  'critical care and intensive care medicine': 'Medicine',
  'dermatology': 'Medicine',
  'diabetes and metabolism': 'Medicine',
  'drug guides': 'Medicine',
  'embryology': 'Medicine',
  'emergency medicine': 'Medicine',
  'endocrinology, diabetes and metabolism': 'Medicine',
  'epidemiology': 'Medicine',
  'family practice': 'Medicine',
  'gastroenterology': 'Medicine',
  'genetics(clinical)': 'Medicine',
  'genetics (clinical)': 'Medicine',
  'geriatrics and gerontology': 'Medicine',
  'health informatics': 'Medicine',
  'health policy': 'Medicine',
  'hematology': 'Medicine',
  'hepatology': 'Medicine',
  'histology': 'Medicine',
  'immunology and allergy': 'Medicine',
  'infectious diseases': 'Medicine',
  'internal medicine': 'Medicine',
  'medical': 'Medicine',
  'microbiology (medical)': 'Medicine',
  'nephrology': 'Medicine',
  'obstetrics and gynecology': 'Medicine',
  'oncology': 'Medicine',
  'ophthalmology': 'Medicine',
  'orthopedics and sports medicine': 'Medicine',
  'otorhinolaryngology': 'Medicine',
  'pathology and forensic medicine': 'Medicine',
  'pediatrics, perinatology and child health': 'Medicine',
  'pharmacology (medical)': 'Medicine',
  'physiology (medical)': 'Medicine',
  'psychiatry and mental health': 'Medicine',
  'public health, environmental and occupational health': 'Medicine',
  'pulmonary and respiratory medicine': 'Medicine',
  'radiology, nuclear medicine and imaging': 'Medicine',
  'radiology nuclear medicine and imaging': 'Medicine',
  'rehabilitation': 'Medicine',
  'reproductive medicine': 'Medicine',
  'rheumatology': 'Medicine',
  'surgery': 'Medicine',
  'transplantation': 'Medicine',
  'urology': 'Medicine',

  /* ---- Neuroscience ------------------------------------------------------------ */
  'behavioral neuroscience': 'Neuroscience',
  'biological psychiatry': 'Neuroscience',
  'cellular and molecular neuroscience': 'Neuroscience',
  'cognitive neuroscience': 'Neuroscience',
  'developmental neuroscience': 'Neuroscience',
  'endocrine and autonomic systems': 'Neuroscience',
  'neurology': 'Neuroscience',
  'sensory systems': 'Neuroscience',

  /* ---- Nursing ------------------------------------------------------------------ */
  'advanced and specialised nursing': 'Nursing',
  'assessment and diagnosis': 'Nursing',
  'care planning': 'Nursing',
  'community and home care': 'Nursing',
  'critical care nursing': 'Nursing',
  'emergency nursing': 'Nursing',
  'fundamentals and skills': 'Nursing',
  'gerontology': 'Nursing',
  'issues, ethics and legal aspects': 'Nursing',
  'leadership and management': 'Nursing',
  'maternity and midwifery': 'Nursing',
  'medical and surgical nursing': 'Nursing',
  'medical?surgical': 'Nursing',
  'medical-surgical': 'Nursing',
  'nutrition and dietetics': 'Nursing',
  'oncology (nursing)': 'Nursing',
  'pediatrics': 'Nursing',
  'phychiatric mental health': 'Nursing',
  'psychiatric mental health': 'Nursing',
  'research and theory': 'Nursing',
  'review and exam preparation': 'Nursing',

  /* ---- Pharmacology, Toxicology and Pharmaceutics -------------------------------- */
  'drug discovery': 'Pharmacology, Toxicology and Pharmaceutics',
  'pharmaceutical science': 'Pharmacology, Toxicology and Pharmaceutics',
  'pharmacology': 'Pharmacology, Toxicology and Pharmaceutics',
  'toxicology': 'Pharmacology, Toxicology and Pharmaceutics',

  /* ---- Physics and Astronomy ------------------------------------------------------ */
  'acoustics and ultrasonics': 'Physics and Astronomy',
  'astronomy and astrophysics': 'Physics and Astronomy',
  'atomic and molecular physics, and optics': 'Physics and Astronomy',
  'condensed matter physics': 'Physics and Astronomy',
  'instrumentation': 'Physics and Astronomy',
  'nuclear and high energy physics': 'Physics and Astronomy',
  'radiation': 'Physics and Astronomy',
  'statistical and nonlinear physics': 'Physics and Astronomy',
  'surfaces and interfaces': 'Physics and Astronomy',

  /* ---- Psychology ------------------------------------------------------------------ */
  'applied psychology': 'Psychology',
  'clinical psychology': 'Psychology',
  'developmental and educational psychology': 'Psychology',
  'experimental and cognitive psychology': 'Psychology',
  'neuropsychology and physiological psychology': 'Psychology',
  'social psychology': 'Psychology',

  /* ---- Social Sciences -------------------------------------------------------------- */
  'anthropology': 'Social Sciences',
  'archeology': 'Social Sciences',
  'communication': 'Social Sciences',
  'cultural studies': 'Social Sciences',
  'demography': 'Social Sciences',
  'development': 'Social Sciences',
  'education': 'Social Sciences',
  'gender studies': 'Social Sciences',
  'geography, planning and development': 'Social Sciences',
  'health (social science)': 'Social Sciences',
  'health(social science)': 'Social Sciences',
  'human factors and ergonomics': 'Social Sciences',
  'law': 'Social Sciences',
  'library and information sciences': 'Social Sciences',
  'life-span and life-course studies': 'Social Sciences',
  'linguistics and language': 'Social Sciences',
  'political science and international relations': 'Social Sciences',
  'public administration': 'Social Sciences',
  'safety research': 'Social Sciences',
  'social work': 'Social Sciences',
  'sociology and political science': 'Social Sciences',
  'transportation': 'Social Sciences',
  'urban studies': 'Social Sciences',

  /* ---- Veterinary ---------------------------------------------------------------------- */
  'equine': 'Veterinary',
  'food animals': 'Veterinary',
  'small animals': 'Veterinary'
};

/* --------------------------------------------------------------------------
   Resolve one narrow subject name to a top-level area, or '' if unknown.
   -------------------------------------------------------------------------- */
ONOS.areaFor = function (subject) {
  var s = String(subject == null ? '' : subject).replace(/\s+/g, ' ').trim();
  if (!s) return '';

  var lower = s.toLowerCase();

  // 1. Exact area name, e.g. "Multidisciplinary"
  for (var i = 0; i < ONOS.AREAS.length; i++) {
    if (ONOS.AREAS[i].toLowerCase() === lower) return ONOS.AREAS[i];
  }

  // 2. Self-naming forms: "General X" and "X (miscellaneous)".
  //    Spelling of "miscellaneous" varies in the source data, so be lenient.
  var m = /^general (.+)$/.exec(lower);
  if (!m) m = /^(.+?)\s*\(mis[a-z]*\)$/.exec(lower);
  if (m) {
    var base = m[1].trim();
    for (var k = 0; k < ONOS.AREAS.length; k++) {
      if (ONOS.AREAS[k].toLowerCase() === base) return ONOS.AREAS[k];
    }
    // e.g. "General Immunology and Microbiology" already handled above;
    // fall through to the table for anything else.
    if (ONOS.SUB_TO_AREA[base]) return ONOS.SUB_TO_AREA[base];
  }

  // 3. The lookup table
  if (ONOS.SUB_TO_AREA[lower]) return ONOS.SUB_TO_AREA[lower];

  // 4. Unknown — record it so it can be added later, then skip.
  ONOS.unmappedSubjects = ONOS.unmappedSubjects || {};
  ONOS.unmappedSubjects[s] = (ONOS.unmappedSubjects[s] || 0) + 1;
  return '';
};

/** Roll a journal's narrow subjects up to its distinct top-level areas. */
ONOS.areasFor = function (subjects) {
  var out = [];
  (subjects || []).forEach(function (s) {
    var a = ONOS.areaFor(s);
    if (a && out.indexOf(a) === -1) out.push(a);
  });
  return out.sort();
};
