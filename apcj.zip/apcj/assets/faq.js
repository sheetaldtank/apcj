/* ==========================================================================
   faq.js — live search + category filtering for faq.html
   Operates directly over the markup: each Q&A is a
   <details class="qa" data-cat="..."> inside a <section class="faq-group">.
   The questions live in the HTML (not in JS) so they stay readable with
   JavaScript off, printable, and indexable by search engines.
   ========================================================================== */

(function () {
  'use strict';

  var input   = document.getElementById('fq');
  var chips   = document.getElementById('fchips');
  var empty   = document.getElementById('fempty');
  var counter = document.getElementById('fcount');
  var qas     = Array.prototype.slice.call(document.querySelectorAll('details.qa'));
  var groups  = Array.prototype.slice.call(document.querySelectorAll('.faq-group'));

  if (!qas.length) return;

  // Cache each question's searchable text once, up front.
  qas.forEach(function (d) {
    d._text = norm(d.textContent);
    d._cat  = d.getAttribute('data-cat') || '';
  });

  var state = { q: '', cat: 'all' };

  function apply() {
    var q = norm(state.q);
    var shown = 0;

    qas.forEach(function (d) {
      var show = (state.cat === 'all' || d._cat === state.cat) &&
                 (!q || d._text.indexOf(q) !== -1);
      d.style.display = show ? '' : 'none';
      // Auto-expand matches while searching; collapse again when cleared.
      if (q && show) d.open = true;
      if (!q) d.open = false;
      if (show) shown++;
    });

    // Hide a category heading when none of its questions survived the filter.
    groups.forEach(function (g) {
      var any = Array.prototype.slice.call(g.querySelectorAll('details.qa'))
        .some(function (d) { return d.style.display !== 'none'; });
      g.style.display = any ? '' : 'none';
    });

    if (empty) empty.style.display = shown ? 'none' : '';
    if (counter) {
      counter.textContent = (state.q || state.cat !== 'all')
        ? shown + ' of ' + qas.length + ' questions'
        : qas.length + ' questions';
    }
  }

  if (input) {
    input.addEventListener('input', debounce(function () {
      state.q = input.value.trim();
      apply();
    }, 150));

    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { input.value = ''; state.q = ''; apply(); }
    });
  }

  if (chips) {
    chips.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-cat]');
      if (!b) return;
      state.cat = b.getAttribute('data-cat');
      chips.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      apply();
    });
  }

  // Deep link: faq.html#q19 opens and scrolls to that question.
  function openFromHash() {
    var id = location.hash.slice(1);
    if (!id) return;
    var t = document.getElementById(id);
    if (t && t.tagName === 'DETAILS') {
      t.open = true;
      t.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }
  window.addEventListener('hashchange', openFromHash);

  apply();
  openFromHash();
})();
