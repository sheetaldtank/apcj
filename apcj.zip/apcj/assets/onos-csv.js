/* ==========================================================================
   onos-csv.js — reads the official ONOS APC title list straight from CSV,
   in the browser, at page load.

   WHY
   ---
   So that updating the journal list is a one-file operation: download the
   new CSV from https://www.onos.gov.in/apc-support, upload it over
   assets/APC_Journal_Titles.csv in cPanel File Manager, done. No build step,
   no scripts to run, no code to edit. Every count and search index on the
   site rebuilds itself from the file on the next page load.

   The parser deliberately handles the official export as-is, quirks included:
     · a UTF-8 BOM and three preamble note lines above the real header
     · quoted fields containing commas, and "" escaped quotes
     · CRLF line endings
     · Subjects cells that are comma-separated, even though some Scopus
       category names contain commas themselves (see COMMA_CATEGORIES)

   If the CSV cannot be read — most often when the page is opened straight
   from disk with file://, where browsers block local fetches — the site
   falls back to the copy baked into journals-data.js, so it always renders.
   ========================================================================== */

var ONOS = window.ONOS || (window.ONOS = {});

/** Where the list lives, relative to the HTML pages. */
ONOS.CSV_URL = 'assets/APC_Journal_Titles.csv';

/* --------------------------------------------------------------------------
   Scopus ASJC category names that contain a comma.
   The Subjects column is comma-separated, so without protecting these a plain
   split turns "Ecology, Evolution, Behavior and Systematics" into three
   meaningless tags. Add to this list if a future revision introduces another.
   -------------------------------------------------------------------------- */
ONOS.COMMA_CATEGORIES = [
  'Ecology, Evolution, Behavior and Systematics',
  'Atomic and Molecular Physics, and Optics',
  'Public Health, Environmental and Occupational Health',
  'Physical Therapy, Sports Therapy and Rehabilitation',
  'Renewable Energy, Sustainability and the Environment',
  'Pharmacology, Toxicology and Pharmaceutics',
  'Biochemistry, Genetics and Molecular Biology',
  'Management, Monitoring, Policy and Law',
  'Pediatrics, Perinatology and Child Health',
  'Radiology, Nuclear Medicine and Imaging',
  'Tourism, Leisure and Hospitality Management',
  'Economics, Econometrics and Finance',
  'Electronic, Optical and Magnetic Materials',
  'Business, Management and Accounting',
  'Statistics, Probability and Uncertainty',
  'Safety, Risk, Reliability and Quality',
  'Geography, Planning and Development',
  'Health, Toxicology and Mutagenesis',
  'Issues, Ethics and Legal Aspects',
  'Surfaces, Coatings and Films'
];

/* Column-name variants, matched case- and punctuation-insensitively. */
ONOS.ALIASES = {
  title:    ['title', 'journaltitle', 'journalname', 'publicationname', 'sourcetitle', 'journal'],
  issn:     ['issn', 'printissn', 'pissn', 'issnprint'],
  eissn:    ['eissn', 'onlineissn', 'electronicissn', 'issnonline'],
  subjects: ['subjects', 'subject', 'subjectarea', 'subjectareas', 'subjectcategory',
             'discipline', 'category', 'categories', 'asjc'],
  publisher:['publisher', 'publishername', 'publishinghouse'],
  oa:       ['oa', 'oatype', 'openaccess', 'openaccesstype', 'oastatus', 'accesstype',
             'accessmodel', 'licence', 'license', 'licencetype', 'licensetype', 'journaltype'],
  url:      ['url', 'link', 'homepage', 'homepageurl', 'website', 'weburl',
             'journalurl', 'journallink', 'journalhomepage', 'sourceurl']
};

/* --------------------------------------------------------------------------
   RFC 4180 CSV parser. Returns an array of row arrays.
   -------------------------------------------------------------------------- */
ONOS.parseCSV = function (text) {
  text = String(text == null ? '' : text).replace(/^﻿/, '');
  var rows = [], row = [], field = '', i = 0, inQuotes = false, c;

  while (i < text.length) {
    c = text.charAt(i);

    if (inQuotes) {
      if (c === '"') {
        if (text.charAt(i + 1) === '"') { field += '"'; i += 2; continue; }
        inQuotes = false; i++; continue;
      }
      field += c; i++; continue;
    }

    if (c === '"')  { inQuotes = true; i++; continue; }
    if (c === ',')  { row.push(field); field = ''; i++; continue; }
    if (c === '\r') { i++; continue; }
    if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }

    field += c; i++;
  }
  if (field !== '' || row.length) { row.push(field); rows.push(row); }
  return rows;
};

/* --------------------------------------------------------------------------
   Helpers
   -------------------------------------------------------------------------- */
function onosSlug(s) { return String(s == null ? '' : s).toLowerCase().replace(/[^a-z0-9]/g, ''); }
function onosClean(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); }

/** Split a Subjects cell, keeping comma-bearing ASJC names intact. */
ONOS.splitSubjects = function (value) {
  var s = onosClean(value);
  if (!s) return [];

  var protectedNames = [];
  ONOS.COMMA_CATEGORIES.forEach(function (name) {
    protectedNames.push(name, 'General ' + name);
  });
  // Longest first, so a shorter name can't consume part of a longer one.
  protectedNames.sort(function (a, b) { return b.length - a.length; });

  // Markers are delimited by NUL, which cannot occur in real data.
  var MARK = '\u0000';
  protectedNames.forEach(function (name, idx) {
    var re = new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig');
    s = s.replace(re, MARK + idx + MARK);
  });

  var out = [];
  s.split(/[;,|]/).forEach(function (part) {
    part = onosClean(part);
    if (!part) return;

    // Restore markers wherever they occur, not only when the entire part is
    // one. ASJC names are frequently suffixed, for example
    //   "Biochemistry, Genetics and Molecular Biology (miscellaneous)"
    // which after protection is a marker followed by " (miscellaneous)".
    // Matching only whole parts left the raw marker visible as "18 (misc...)".
    part = onosClean(part.replace(/\u0000(\d+)\u0000/g, function (_, i) {
      return protectedNames[+i] || '';
    }));

    // Belt and braces: never emit a tag that still carries a marker.
    if (!part || part.indexOf(MARK) !== -1) return;
    if (out.indexOf(part) === -1) out.push(part);
  });
  return out;
};

/* --------------------------------------------------------------------------
   Turn parsed rows into journal records.
   Finds the header row rather than assuming row 1, so the export's preamble
   notes are skipped automatically.
   -------------------------------------------------------------------------- */
ONOS.rowsToJournals = function (rows) {
  var lookup = {};
  Object.keys(ONOS.ALIASES).forEach(function (field) {
    ONOS.ALIASES[field].forEach(function (n) { lookup[onosSlug(n)] = field; });
  });

  var headerIdx = -1, colmap = null;
  for (var r = 0; r < Math.min(rows.length, 25); r++) {
    var m = {};
    rows[r].forEach(function (cell, i) {
      var f = lookup[onosSlug(cell)];
      if (f && !(f in m)) m[f] = i;
    });
    if ('title' in m) { headerIdx = r; colmap = m; break; }
  }
  if (headerIdx === -1) throw new Error('no journal-title column found in the first 25 rows');

  // The export stamps its download date in the preamble; surface it so the
  // page can show how fresh the list is.
  ONOS.meta = { downloaded: '', header: headerIdx + 1 };
  for (var p = 0; p < headerIdx; p++) {
    var joined = rows[p].join(' ');
    var d = /Downloaded\s+On\s+([0-9:\-\/\s]+)/i.exec(joined);
    if (d) ONOS.meta.downloaded = onosClean(d[1]);
  }

  var out = [], seen = {};
  for (var i = headerIdx + 1; i < rows.length; i++) {
    var raw = rows[i];
    if (!raw || !raw.join('').trim()) continue;

    var title = onosClean(raw[colmap.title]);
    if (!title) continue;
    var key = title.toLowerCase();
    if (seen[key]) continue;
    seen[key] = 1;

    var rec = { title: title, issn: '', eissn: '', subjects: [] };
    if ('issn' in colmap)      rec.issn      = onosClean(raw[colmap.issn]);
    if ('eissn' in colmap)     rec.eissn     = onosClean(raw[colmap.eissn]);
    if ('publisher' in colmap) rec.publisher = onosClean(raw[colmap.publisher]);
    if ('oa' in colmap)        rec.oa        = onosClean(raw[colmap.oa]);
    if ('url' in colmap) {
      var u = onosClean(raw[colmap.url]);
      // Only accept absolute http(s) links — anything else would produce a
      // link relative to this site, which would 404.
      rec.url = /^https?:\/\//i.test(u) ? u : '';
    }
    if ('subjects' in colmap)  rec.subjects  = ONOS.splitSubjects(raw[colmap.subjects]);

    // Roll the narrow Scopus categories up to the 27 top-level ASJC subject
    // areas, so the page can offer a broad-discipline filter as well.
    rec.areas = (typeof ONOS.areasFor === 'function') ? ONOS.areasFor(rec.subjects) : [];
    out.push(rec);
  }

  out.sort(function (a, b) { return a.title.toLowerCase() < b.title.toLowerCase() ? -1 : 1; });
  return out;
};

/* --------------------------------------------------------------------------
   Load the list. Resolves to the array and records where it came from.
   -------------------------------------------------------------------------- */
ONOS.load = function () {
  return new Promise(function (resolve) {
    function useFallback(why) {
      ONOS.source = 'fallback';
      ONOS.reason = why;
      resolve(typeof JOURNALS_FALLBACK !== 'undefined' ? JOURNALS_FALLBACK : []);
    }

    if (typeof fetch !== 'function' || location.protocol === 'file:') {
      // Browsers refuse local fetches from file://; the baked-in copy covers it.
      return useFallback(location.protocol === 'file:'
        ? 'opened from disk (file://), where browsers block reading local files'
        : 'this browser has no fetch()');
    }

    fetch(ONOS.CSV_URL, { cache: 'no-cache' })
      .then(function (res) {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.text();
      })
      .then(function (text) {
        var list = ONOS.rowsToJournals(ONOS.parseCSV(text));
        if (!list.length) throw new Error('parsed 0 journals');
        ONOS.source = 'csv';
        resolve(list);
      })
      .catch(function (err) { useFallback(String(err.message || err)); });
  });
};
