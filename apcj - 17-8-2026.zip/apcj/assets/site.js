/* ==========================================================================
   site.js — shared behaviour for the ONOS APC Support Hub
   Loaded by every page. No dependencies, no build step, no network calls.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. SITE CONFIG
   The single source of truth for every institution-specific string.
   Edit here and it propagates to all four pages via  data-cfg="key".
   -------------------------------------------------------------------------- */
const SITE = {
  /* ---- Institute -------------------------------------------------------- */
  institute:      'Indian Institute of Technology Gandhinagar',
  instShort:      'IIT Gandhinagar',
  library:        'IIT Gandhinagar Library',
  libraryShort:   'IITGN Library',
  address:        'Palaj, Gandhinagar, Gujarat – 382355',
  location:       'Main Library, Block 13',
  instituteCode:  'U-0139',              // AISHE code, per the ONOS admin panel
  emailDomain:    '@iitgn.ac.in',

  /* ---- Library / ONOS Nodal Officer ------------------------------------- */
  librarian:      'Dr. Kannan Palavesam',
  librarianRole:  'Librarian',
  libraryEmail:   'librarian@iitgn.ac.in',
  nodalEmail:     'kannan.p@iitgn.ac.in',
  libraryPhone:   '079 3245 1126',
  libraryMobile:  '+91 97255 32351',

  /* ---- STILL TO CONFIRM --------------------------------------------------
     The Head-of-Institution endorsement signatory is not recorded on the ONOS
     admin panel. Confirm with the Dean's office, set it here, then remove the
     two "Confirm locally" markers — guidelines.html §5 and faq.html Q19.
     ---------------------------------------------------------------------- */
  signingAuth:    'Dean, Academic Affairs',

  /* ---- ONOS / INFLIBNET -------------------------------------------------- */
  onosEmail:      'apcsupport@onos.gov.in',
  onosPhone:      '+91-79-2326 8246',
  payDays:        '15–20 working days',
  reviewed:       'August 2026'
};

/* --------------------------------------------------------------------------
   2. Config interpolation:  <span data-cfg="signingAuth"></span>
   The text already in the element is a no-JS fallback; this overwrites it.
   -------------------------------------------------------------------------- */
function applyConfig(root) {
  (root || document).querySelectorAll('[data-cfg]').forEach(function (el) {
    var k = el.getAttribute('data-cfg');
    if (Object.prototype.hasOwnProperty.call(SITE, k)) el.textContent = SITE[k];
  });
}

/* --------------------------------------------------------------------------
   3a. The journal list.
   Filled by ONOS.load() from assets/APC_Journal_Titles.csv at page load, with
   journals-data.js as the offline fallback. Anything that needs the data waits
   on ONOS.ready rather than reading JOURNALS directly at parse time.
   -------------------------------------------------------------------------- */
var JOURNALS = [];

ONOS.ready = ONOS.load().then(function (list) {
  JOURNALS = list;
  return list;
});

/* --------------------------------------------------------------------------
   3b. Journal count — single source of truth is the JOURNALS array, so the
   hero stat, the guidelines and the FAQ never drift out of sync with the data.
   -------------------------------------------------------------------------- */
function applyJournalCount(root) {
  if (!JOURNALS || !JOURNALS.length) return;
  var n = JOURNALS.length;
  (root || document).querySelectorAll('[data-jcount]').forEach(function (el) {
    el.textContent = n;
  });
}

/* --------------------------------------------------------------------------
   4. Mark the current page in the nav bar
   -------------------------------------------------------------------------- */
function markActiveNav() {
  var here = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  document.querySelectorAll('.nav a').forEach(function (a) {
    if ((a.getAttribute('href') || '').toLowerCase() === here) a.classList.add('active');
  });
}

/* --------------------------------------------------------------------------
   5. Back-to-top button
   -------------------------------------------------------------------------- */
function initBackToTop() {
  var btn = document.getElementById('totop');
  if (!btn) return;
  var onScroll = function () { btn.classList.toggle('show', window.scrollY > 420); };
  window.addEventListener('scroll', onScroll, { passive: true });
  btn.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
  onScroll();
}

/* --------------------------------------------------------------------------
   6. TOC scroll-spy (guidelines page)
   -------------------------------------------------------------------------- */
function initScrollSpy() {
  var links = Array.prototype.slice.call(document.querySelectorAll('.toc a[href^="#"]'));
  if (!links.length) return;

  var targets = links.map(function (a) {
    var el = document.getElementById(a.getAttribute('href').slice(1));
    return el ? { link: a, el: el } : null;
  }).filter(Boolean);

  if (!targets.length) return;

  var tick = function () {
    var y = window.scrollY + 140;
    var current = targets[0];
    for (var i = 0; i < targets.length; i++) {
      if (targets[i].el.offsetTop <= y) current = targets[i];
    }
    links.forEach(function (a) { a.classList.remove('on'); });
    current.link.classList.add('on');
  };

  window.addEventListener('scroll', tick, { passive: true });
  tick();
}

/* --------------------------------------------------------------------------
   7. Shared helpers used by faq.js and onoslist.js
   -------------------------------------------------------------------------- */

/** Escape a string for safe insertion as HTML text. */
function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/** Escape a string for literal use inside a RegExp. */
function escRe(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Fold accents and lowercase, so "Zeitschrift für" matches "zeitschrift fur". */
function norm(s) {
  return String(s == null ? '' : s)
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toLowerCase();
}

/** Wrap occurrences of `term` in <mark>. Escapes first, so this is XSS-safe. */
function highlight(text, term) {
  var safe = esc(text);
  if (!term) return safe;
  try {
    return safe.replace(new RegExp('(' + escRe(esc(term)) + ')', 'gi'), '<mark>$1</mark>');
  } catch (e) {
    return safe;
  }
}

/** Debounce — keeps search inputs from re-rendering on every keystroke. */
function debounce(fn, ms) {
  var t;
  return function () {
    var args = arguments, self = this;
    clearTimeout(t);
    t = setTimeout(function () { fn.apply(self, args); }, ms || 180);
  };
}

/** Trigger a client-side file download (used for the CSV export). */
function downloadBlob(filename, mime, text) {
  var blob = new Blob(['﻿' + text], { type: mime + ';charset=utf-8;' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
}

/* --------------------------------------------------------------------------
   8. Boot
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {
  applyConfig();
  markActiveNav();
  initBackToTop();
  initScrollSpy();
  // Counts appear once the CSV has been read (or the fallback kicks in).
  ONOS.ready.then(function () { applyJournalCount(); });
});
