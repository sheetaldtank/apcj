/* ==========================================================================
   onoslist.js — ONOS APC eligible-journal browser
   Search + A–Z + subject facet + sort + paging + CSV export.

   Results render as cards rather than table rows, matching the layout of the
   Library's own e-Journals Discovery page. Reads the JOURNALS array from
   journals-data.js. Entirely client-side: no network calls, no dependencies.

   Record shape: { title, issn, eissn, subjects: [], publisher?, oa?, url? }
   Publisher, OA type and URL are optional — the UI adapts to what the CSV has.
   ========================================================================== */

ONOS.ready.then(function (JOURNALS) {
  'use strict';

  var state = {
    q: '', letter: '', subject: '', publisher: '', oa: '',
    sortDir: 1,            // 1 = A→Z, -1 = Z→A
    page: 1, perPage: 25
  };

  var el = {
    q:       document.getElementById('jq'),
    clear:   document.getElementById('jclear'),
    az:      document.getElementById('az'),
    subject: document.getElementById('fsub'),
    publisher: document.getElementById('fpub'),
    oa:        document.getElementById('foa'),
    sort:    document.getElementById('fsort'),
    perPage: document.getElementById('fper'),
    reset:   document.getElementById('freset'),
    csv:     document.getElementById('fcsv'),
    big:     document.getElementById('jbig'),
    count:   document.getElementById('jcount'),
    body:    document.getElementById('jbody'),
    empty:   document.getElementById('jempty'),
    pager:   document.getElementById('jpager'),
    modal:   document.getElementById('jmodal'),
    mtitle:  document.getElementById('jmtitle'),
    mbody:   document.getElementById('jmbody'),
    mclose:  document.getElementById('jmclose'),
    sample:  document.getElementById('jsample')
  };

  /* ---- Tell the reader (and the maintainer) where the data came from --- */
  function showSource() {
    var box = el.sample;
    if (!box) return;
    box.style.display = '';

    if (ONOS.source === 'csv') {
      box.className = 'note info';
      box.innerHTML =
        'Loaded directly from <code>assets/APC_Journal_Titles.csv</code>' +
        (ONOS.meta && ONOS.meta.downloaded
          ? ' — ONOS export dated <strong>' + esc(ONOS.meta.downloaded) + '</strong>' : '') +
        '. To publish a revised list, replace that one file.';
    } else {
      // Worth surfacing loudly: on the live server this means the CSV is
      // missing or unreadable, and visitors are seeing a possibly stale copy.
      box.className = 'note danger';
      box.innerHTML =
        '<strong>Showing the built-in copy of the list.</strong> ' +
        '<code>assets/APC_Journal_Titles.csv</code> could not be read &mdash; ' +
        esc(ONOS.reason || 'unknown reason') + '. ' +
        'On the server, check that the file is present in <code>assets/</code> and publicly readable.';
    }
  }

  /* ---- Precompute per record ------------------------------------------- */
  // Normalising 426 records once at load, rather than on every keystroke.
  function firstLetter(title) {
    var t = norm(title).replace(/^(the|a|an)\s+/, '');
    var c = t.charAt(0).toUpperCase();
    return /[A-Z]/.test(c) ? c : '#';
  }

  JOURNALS.forEach(function (j) {
    j._hay = norm([j.title, j.publisher, j.oa, j.issn, j.eissn, (j.subjects || []).join(' ')].join(' '));
    j._letter = firstLetter(j.title);
  });

  /* ---- Subject facet --------------------------------------------------- */
  (function buildSubjects() {
    if (!el.subject) return;
    var counts = Object.create(null);
    JOURNALS.forEach(function (j) {
      (j.subjects || []).forEach(function (s) { counts[s] = (counts[s] || 0) + 1; });
    });
    var names = Object.keys(counts).sort(function (a, b) { return a.localeCompare(b); });
    var html = '<option value="">All subjects (' + names.length + ')</option>';
    names.forEach(function (n) {
      html += '<option value="' + esc(n) + '">' + esc(n) + ' (' + counts[n] + ')</option>';
    });
    el.subject.innerHTML = html;
  })();

  /* ---- Publisher facet -------------------------------------------------
     The official ONOS export has no publisher column. If a future export
     gains one — or the Library adds one — this facet appears by itself;
     until then it stays hidden rather than showing an empty dropdown.
     ---------------------------------------------------------------------- */
  /** Build a dropdown from one field; hide the whole control if the CSV
      supplies no values for it. Returns whether the field is populated. */
  function buildFacet(select, wrapId, field, allLabel) {
    var wrap = document.getElementById(wrapId);
    var present = JOURNALS.some(function (j) { return j[field]; });
    if (!select || !wrap) return present;
    if (!present) { wrap.style.display = 'none'; return false; }

    var counts = Object.create(null);
    JOURNALS.forEach(function (j) {
      if (j[field]) counts[j[field]] = (counts[j[field]] || 0) + 1;
    });
    var names = Object.keys(counts).sort(function (a, b) { return a.localeCompare(b); });
    var html = '<option value="">' + esc(allLabel) + ' (' + names.length + ')</option>';
    names.forEach(function (n) {
      html += '<option value="' + esc(n) + '">' + esc(n) + ' (' + counts[n] + ')</option>';
    });
    select.innerHTML = html;
    wrap.style.display = '';
    return true;
  }

  var HAS_PUBLISHER = buildFacet(el.publisher, 'fpubwrap', 'publisher', 'All publishers');
  var HAS_OA        = buildFacet(el.oa,        'foawrap',  'oa',        'All OA types');
  // URL needs no facet — it is a link, not something you filter by.
  var HAS_URL       = JOURNALS.some(function (j) { return j.url; });

  /* ---- A–Z strip ------------------------------------------------------- */
  (function buildAZ() {
    if (!el.az) return;
    var present = Object.create(null);
    JOURNALS.forEach(function (j) { present[j._letter] = true; });

    var html = '<button data-l="" class="on">All</button>';
    for (var i = 65; i <= 90; i++) {
      var L = String.fromCharCode(i);
      // Letters with no journals stay visible but disabled, so the strip keeps
      // a stable width when the underlying list is revised.
      html += '<button data-l="' + L + '"' + (present[L] ? '' : ' disabled') + '>' + L + '</button>';
    }
    if (present['#']) html += '<button data-l="#">#</button>';
    el.az.innerHTML = html;
  })();

  /* ---- Filtering ------------------------------------------------------- */
  function matches(j) {
    if (state.publisher && j.publisher !== state.publisher) return false;
    if (state.oa && j.oa !== state.oa) return false;
    if (state.subject && (j.subjects || []).indexOf(state.subject) === -1) return false;
    if (state.letter && j._letter !== state.letter) return false;
    if (state.q) {
      var toks = norm(state.q).split(/\s+/).filter(Boolean);
      for (var i = 0; i < toks.length; i++) {
        if (j._hay.indexOf(toks[i]) === -1) return false;   // AND across tokens
      }
    }
    return true;
  }

  /* ---- Rendering ------------------------------------------------------- */
  var filtered = [];
  var PILL = ['', ' v', ' g'];   // blue / violet / green, as on the Library site

  /** Stable colour per subject, so a tag looks the same everywhere. */
  function pillClass(s) {
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    return PILL[h % PILL.length];
  }

  function pills(j) {
    var s = j.subjects || [];
    if (!s.length) return '';
    var out = s.slice(0, 4).map(function (x) {
      return '<span class="pill' + pillClass(x) + '">' + esc(x) + '</span>';
    });
    if (s.length > 4) out.push('<span class="pill more">+' + (s.length - 4) + ' more</span>');
    return '<div class="pills">' + out.join('') + '</div>';
  }

  /** Gold / Diamond / Hybrid read differently to a researcher, so they get
      distinct colours rather than one generic badge. */
  function oaClass(v) {
    var t = norm(v);
    if (t.indexOf('diamond') !== -1 || t.indexOf('platinum') !== -1) return 'oa dia';
    if (t.indexOf('hybrid') !== -1) return 'oa hyb';
    if (t.indexOf('green') !== -1) return 'oa grn';
    return 'oa gold';
  }

  function oaBadge(j) {
    return j.oa ? '<span class="' + oaClass(j.oa) + '">' + esc(j.oa) + '</span>' : '';
  }

  function pubLine(j) {
    return j.publisher ? '<div class="jpub">' + highlight(j.publisher, state.q) + '</div>' : '';
  }

  function metaLine(j) {
    var bits = [];
    if (j.issn)  bits.push('<span><span class="k">ISSN</span> <span class="issn">' + esc(j.issn) + '</span></span>');
    if (j.eissn) bits.push('<span><span class="k">e-ISSN</span> <span class="issn">' + esc(j.eissn) + '</span></span>');
    if (!bits.length) bits.push('<span class="dash">No ISSN listed</span>');
    return '<div class="jmeta">' + bits.join('') + '</div>';
  }

  function render() {
    filtered = JOURNALS.filter(matches).sort(function (a, b) {
      return a.title.localeCompare(b.title, undefined, { sensitivity: 'base' }) * state.sortDir;
    });

    var total = filtered.length;
    var pages = Math.max(1, Math.ceil(total / state.perPage));
    if (state.page > pages) state.page = pages;
    var start = (state.page - 1) * state.perPage;
    var slice = filtered.slice(start, start + state.perPage);

    if (el.big) el.big.textContent = total.toLocaleString('en-IN');
    if (el.count) {
      el.count.innerHTML = total
        ? 'Showing <b>' + (start + 1) + '–' + (start + slice.length) + '</b>' +
          (total !== JOURNALS.length
            ? ' <span class="of">· filtered from ' + JOURNALS.length + '</span>' : '')
        : '';
    }

    if (el.body) {
      el.body.innerHTML = slice.map(function (j) {
        var titleHtml = j.url
          ? '<a href="' + esc(j.url) + '" target="_blank" rel="noopener">' +
            highlight(j.title, state.q) + '<span class="ext" aria-hidden="true">\u2197</span></a>'
          : highlight(j.title, state.q);
        return '<article class="jcard" data-i="' + JOURNALS.indexOf(j) + '" tabindex="0">' +
          '<div class="jtitle">' + titleHtml + oaBadge(j) + '</div>' +
          pubLine(j) + metaLine(j) + pills(j) +
          '</article>';
      }).join('');
      el.body.style.display = total ? '' : 'none';
    }

    if (el.empty) el.empty.style.display = total ? 'none' : '';
    renderPager(pages);
  }

  function renderPager(pages) {
    if (!el.pager) return;
    if (pages <= 1) { el.pager.innerHTML = ''; return; }

    var p = state.page, out = [];
    out.push('<button data-p="' + (p - 1) + '"' + (p === 1 ? ' disabled' : '') + '>‹ Prev</button>');

    var nums = [];
    for (var i = 1; i <= pages; i++) {
      if (i === 1 || i === pages || Math.abs(i - p) <= 2) nums.push(i);
    }
    var last = 0;
    nums.forEach(function (n) {
      if (last && n - last > 1) out.push('<span class="gap">…</span>');
      out.push('<button data-p="' + n + '"' + (n === p ? ' class="on"' : '') + '>' + n + '</button>');
      last = n;
    });

    out.push('<button data-p="' + (p + 1) + '"' + (p === pages ? ' disabled' : '') + '>Next ›</button>');
    el.pager.innerHTML = out.join('');
  }

  /* ---- Detail dialog --------------------------------------------------- */
  function openDetail(idx) {
    var j = JOURNALS[idx];
    if (!j || !el.modal) return;

    var subs = (j.subjects || []).length
      ? '<div class="pills">' + j.subjects.map(function (s) {
          return '<span class="pill' + pillClass(s) + '">' + esc(s) + '</span>';
        }).join('') + '</div>'
      : '<span class="dash">—</span>';

    el.mtitle.textContent = j.title;
    el.mbody.innerHTML =
      '<dl>' +
      (j.publisher ? '<dt>Publisher</dt><dd>' + esc(j.publisher) + '</dd>' : '') +
      '<dt>Print ISSN</dt><dd>' + (j.issn ? '<span class="issn">' + esc(j.issn) + '</span>' : '<span class="dash">—</span>') + '</dd>' +
      '<dt>Online ISSN</dt><dd>' + (j.eissn ? '<span class="issn">' + esc(j.eissn) + '</span>' : '<span class="dash">—</span>') + '</dd>' +
      '<dt>Access type</dt><dd>' + (j.oa ? esc(j.oa) : 'Gold Open Access') + '</dd>' +
      '<dt>APC status</dt><dd>Eligible for ONOS APC support</dd>' +
      '<dt>Subject areas</dt><dd>' + subs + '</dd>' +
      (j.url ? '<dt>Journal website</dt><dd><a href="' + esc(j.url) +
               '" target="_blank" rel="noopener">' + esc(j.url) + ' \u2197</a></dd>' : '') +
      '</dl>' +
      '<p class="mnote">Re-confirm eligibility on the official list at ' +
      '<a href="https://www.onos.gov.in/apc-support" target="_blank" rel="noopener">onos.gov.in/apc-support</a> ' +
      'before submitting your manuscript.</p>';

    if (typeof el.modal.showModal === 'function') el.modal.showModal();
    else el.modal.setAttribute('open', '');
  }

  function closeDetail() {
    if (!el.modal) return;
    if (typeof el.modal.close === 'function') el.modal.close();
    else el.modal.removeAttribute('open');
  }

  /* ---- CSV export — exports the CURRENT filtered set ------------------- */
  function toCSV(rows) {
    // Only emit columns the source actually provides, so the export mirrors
    // the uploaded file rather than padding it with empty fields.
    var cols = [['Journal Title', function (r) { return r.title; }]];
    if (HAS_PUBLISHER) cols.push(['Publisher', function (r) { return r.publisher || ''; }]);
    cols.push(['Print ISSN',  function (r) { return r.issn; }]);
    cols.push(['Online ISSN', function (r) { return r.eissn; }]);
    if (HAS_OA) cols.push(['OA Type', function (r) { return r.oa || ''; }]);
    if (HAS_URL) cols.push(['URL', function (r) { return r.url || ''; }]);
    cols.push(['Subjects', function (r) { return (r.subjects || []).join('; '); }]);

    var q = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var lines = [cols.map(function (c) { return q(c[0]); }).join(',')];
    rows.forEach(function (r) {
      lines.push(cols.map(function (c) { return q(c[1](r)); }).join(','));
    });
    return lines.join('\r\n');
  }

  /* ---- Events ---------------------------------------------------------- */
  if (el.q) {
    el.q.addEventListener('input', debounce(function () {
      state.q = el.q.value.trim(); state.page = 1; render();
    }, 160));
    // "/" focuses the search box, as on the Library's e-Journals page
    document.addEventListener('keydown', function (e) {
      if (e.key === '/' && document.activeElement !== el.q) { e.preventDefault(); el.q.focus(); }
    });
  }

  if (el.clear) el.clear.addEventListener('click', function () {
    if (el.q) { el.q.value = ''; el.q.focus(); }
    state.q = ''; state.page = 1; render();
  });

  if (el.az) el.az.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-l]');
    if (!b || b.disabled) return;
    state.letter = b.getAttribute('data-l'); state.page = 1;
    el.az.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
    b.classList.add('on');
    render();
  });

  if (el.subject) el.subject.addEventListener('change', function () {
    state.subject = el.subject.value; state.page = 1; render();
  });

  if (el.publisher) el.publisher.addEventListener('change', function () {
    state.publisher = el.publisher.value; state.page = 1; render();
  });

  if (el.oa) el.oa.addEventListener('change', function () {
    state.oa = el.oa.value; state.page = 1; render();
  });

  if (el.sort) el.sort.addEventListener('change', function () {
    state.sortDir = el.sort.value === 'desc' ? -1 : 1; state.page = 1; render();
  });

  if (el.perPage) el.perPage.addEventListener('change', function () {
    state.perPage = parseInt(el.perPage.value, 10) || 25; state.page = 1; render();
  });

  if (el.reset) el.reset.addEventListener('click', function () {
    state.q = ''; state.letter = ''; state.subject = ''; state.publisher = ''; state.oa = '';
    state.sortDir = 1; state.page = 1;
    if (el.q) el.q.value = '';
    if (el.subject) el.subject.value = '';
    if (el.publisher) el.publisher.value = '';
    if (el.oa) el.oa.value = '';
    if (el.sort) el.sort.value = 'asc';
    if (el.az) {
      el.az.querySelectorAll('button').forEach(function (x) { x.classList.remove('on'); });
      var all = el.az.querySelector('button[data-l=""]');
      if (all) all.classList.add('on');
    }
    render();
  });

  if (el.pager) el.pager.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-p]');
    if (!b || b.disabled) return;
    state.page = parseInt(b.getAttribute('data-p'), 10);
    render();
    var top = el.body ? el.body.getBoundingClientRect().top + window.scrollY - 100 : 0;
    window.scrollTo({ top: top, behavior: 'smooth' });
  });

  if (el.body) {
    el.body.addEventListener('click', function (e) {
      // A click on the title link goes to the journal; anywhere else on the
      // card opens the details dialog.
      if (e.target.closest('a')) return;
      var c = e.target.closest('.jcard[data-i]');
      if (c) openDetail(parseInt(c.getAttribute('data-i'), 10));
    });
    el.body.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' && e.key !== ' ') return;
      if (e.target.tagName === 'A') return;
      var c = e.target.closest('.jcard[data-i]');
      if (c) { e.preventDefault(); openDetail(parseInt(c.getAttribute('data-i'), 10)); }
    });
  }

  if (el.mclose) el.mclose.addEventListener('click', closeDetail);
  if (el.modal) el.modal.addEventListener('click', function (e) {
    if (e.target === el.modal) closeDetail();   // backdrop click
  });

  if (el.csv) el.csv.addEventListener('click', function () {
    var stamp = new Date().toISOString().slice(0, 10);
    downloadBlob('onos-apc-journals-' + stamp + '.csv', 'text/csv', toCSV(filtered));
  });

  render();
  showSource();
});
